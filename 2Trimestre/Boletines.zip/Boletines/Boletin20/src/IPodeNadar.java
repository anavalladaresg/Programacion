public interface IPodeNadar {
}
