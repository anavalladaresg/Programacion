public class Papagaio extends Aves implements IPodeCaminar, IPodeVolar {
}
