public class Gato extends Felino implements IPodeCaminar, IPodeNadar {
}