public class Avestruz extends Aves implements IPodeCaminar {
}
