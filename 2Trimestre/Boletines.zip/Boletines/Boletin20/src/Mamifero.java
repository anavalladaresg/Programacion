public class Mamifero implements IPodeCaminar {

}
