public interface IPodeCaminar {
}
