public class Felino extends Mamifero implements IPodeCaminar {
}
