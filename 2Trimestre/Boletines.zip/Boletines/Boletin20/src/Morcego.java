public class Morcego extends Mamifero implements IPodeCaminar, IPodeVolar {
}
