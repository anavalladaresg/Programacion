public class Main {
    public static void main(String[] args) {
        Libreria libreria = new Libreria();
        libreria.pickWhatToDo();
    }
}