public class Persoa implements IPodeCantar {
    public void cantar() {
        System.out.println("Do, re, mi, fa, sol, la, si, do!");
    }
}
