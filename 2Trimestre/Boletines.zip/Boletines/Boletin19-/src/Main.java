public class Main {
    public static void main(String[] args) {
        Canario c = new Canario();
        c.cantar();
        Persoa p = new Persoa();
        p.cantar();
    }
}