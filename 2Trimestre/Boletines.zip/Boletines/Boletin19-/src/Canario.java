public class Canario implements IPodeCantar {
    public void cantar() {
        System.out.println("Pío, pío, pío!");
    }
}
