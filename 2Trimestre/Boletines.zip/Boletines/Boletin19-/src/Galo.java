public class Galo implements IPodeCantar {
    public void cantar() {
        System.out.println("Quiquiriquí!");
    }
}
