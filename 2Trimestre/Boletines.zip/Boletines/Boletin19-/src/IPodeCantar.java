public interface IPodeCantar {
    public void cantar();
}
