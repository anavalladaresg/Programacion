public abstract class Figura {
    public abstract void dibujar();
}