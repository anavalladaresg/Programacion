public interface Vehiculo {
    void arrancar();
    void detener();
    void acelerar();
}