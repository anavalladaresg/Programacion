public class Main {

    public static void main(String[] args) {
        TemperaturaErradaExcepcion t = new TemperaturaErradaExcepcion();
        t.excepcion();
    }

}